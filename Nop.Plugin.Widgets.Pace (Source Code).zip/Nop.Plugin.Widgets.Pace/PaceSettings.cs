﻿using System;
using System.Collections.Generic;
using System.Text;
using Nop.Core.Configuration;

namespace Nop.Plugin.Widgets.Pace
{
    public class PaceSettings : ISettings
    {

        public bool IsActive { get; set; }

        public string Pacetheme { get; set; }

        public string Pacestyle { get; set; }

        public bool IsActiveAdmin { get; set; }

        public string PacethemeAdmin { get; set; }

        public string PacestyleAdmin { get; set; }


    }
}
