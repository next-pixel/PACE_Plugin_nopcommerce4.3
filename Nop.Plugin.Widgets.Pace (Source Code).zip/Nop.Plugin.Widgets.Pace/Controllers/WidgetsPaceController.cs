﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Core;
using Nop.Plugin.Widgets.Pace;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Media;
using Nop.Services.Messages;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;

namespace Nop.Plugin.Widgets.NivoSlider.Controllers
{
    [Area(AreaNames.Admin)]
    [AutoValidateAntiforgeryToken]
    public class WidgetsPaceController : BasePluginController
    {
        private readonly ILocalizationService _localizationService;
        private readonly INotificationService _notificationService;
        private readonly IPermissionService _permissionService;
        private readonly IPictureService _pictureService;
        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;

        public WidgetsPaceController(ILocalizationService localizationService,
            INotificationService notificationService,
            IPermissionService permissionService, 
            IPictureService pictureService,
            ISettingService settingService,
            IStoreContext storeContext)
        {
            _localizationService = localizationService;
            _notificationService = notificationService;
            _permissionService = permissionService;
            _pictureService = pictureService;
            _settingService = settingService;
            _storeContext = storeContext;
        }

        public IActionResult Configure()
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageWidgets))
                return AccessDeniedView();

            //load settings for a chosen store scope
            var storeScope = _storeContext.ActiveStoreScopeConfiguration;
            var paceSettings = _settingService.LoadSetting<PaceSettings>(storeScope);

           


            var model = new PublicInfoModel
            {
                IsActive = paceSettings.IsActive,
                Pacetheme = paceSettings.Pacetheme,
                Pacestyle = paceSettings.Pacestyle,
                IsActiveAdmin = paceSettings.IsActiveAdmin,
                PacethemeAdmin = paceSettings.PacethemeAdmin,
                PacestyleAdmin = paceSettings.PacestyleAdmin
            };



            return View("~/Plugins/Widgets.Pace/Views/Configure.cshtml", model);
        }

        [HttpPost]
        public IActionResult Configure(PublicInfoModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageWidgets))
                return AccessDeniedView();

          

            //load settings for a chosen store scope
            var storeScope = _storeContext.ActiveStoreScopeConfiguration;
            var paceSettings = _settingService.LoadSetting<PaceSettings>(storeScope);

            paceSettings.IsActive = model.IsActive;
            paceSettings.Pacetheme = model.Pacetheme;
            paceSettings.Pacestyle = model.Pacestyle;
            paceSettings.IsActiveAdmin = model.IsActiveAdmin;
            paceSettings.PacethemeAdmin = model.PacethemeAdmin;
            paceSettings.PacestyleAdmin = model.PacestyleAdmin;

            _settingService.SaveSettingOverridablePerStore(paceSettings, x => x.IsActive, true, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(paceSettings, x => x.Pacetheme, true, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(paceSettings, x => x.Pacestyle, true, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(paceSettings, x => x.IsActiveAdmin, true, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(paceSettings, x => x.PacethemeAdmin, true, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(paceSettings, x => x.PacestyleAdmin, true, storeScope, false);
            //_settingService.SaveSettingOverridablePerStore(paceSettings, x => x.IsActive, model.IsActive, storeScope, false);
            //            _settingService.SaveSetting(paceSettings, storeScope);
            // _settingService.SaveSettingOverridablePerStore(paceSettings, x => x.Pacestyle, model.Pacestyle, storeScope, false);

            //now clear settings cache
            _settingService.ClearCache();
            _notificationService.SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"));
            return Configure();
        }
    }
}